import json
import init


NUMS = 30
points = init.create_points(NUMS)
init.write_points(points, "points.json")
